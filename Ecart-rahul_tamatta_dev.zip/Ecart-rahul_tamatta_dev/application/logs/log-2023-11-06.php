<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 19:27:37 --> Severity: error --> Exception: Class "mysqli_driver" not found D:\Programming\SmitoxB2B\New Admin\Ecart\system\database\drivers\mysqli\mysqli_driver.php 123
ERROR - 2023-11-06 20:51:54 --> Severity: error --> Exception: Class "mysqli_driver" not found D:\Programming\SmitoxB2B\New Admin\Ecart\system\database\drivers\mysqli\mysqli_driver.php 123
